
const { exec } = require('child_process')

function run(script, input) {
    return new Promise((resolve, reject) => {
        const p = exec(`python ${script} '${JSON.stringify(input)}'`)
        p.stdout.on('data', d => resolve(d.toString()))
        p.stderr.on('data', e => reject(e.toString()))
    })
}

async function dispatchTask(data) {
    let result1 = await run('../agents/data_agent.py', data)
    let result2 = await run('../agents/analysis_agent.py', JSON.parse(result1))
    let result3 = await run('../agents/report_agent.py', JSON.parse(result2))
    return result3
}

module.exports = { dispatchTask }
