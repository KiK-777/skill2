
const express = require('express')
const bodyParser = require('body-parser')
const { dispatchTask } = require('./agentManager')

const app = express()
app.use(bodyParser.json())

app.post('/analyze', async (req, res) => {
    const { data } = req.body

    try {
        const result = await dispatchTask(data)
        res.json({ success: true, result: JSON.parse(result) })
    } catch (err) {
        res.status(500).json({ success: false, error: err.message })
    }
})

app.listen(3001, () => {
    console.log('Data Analysis Platform running on port 3001')
})
