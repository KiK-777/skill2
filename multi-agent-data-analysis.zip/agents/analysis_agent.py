
import sys, json

data = json.loads(sys.argv[1])
nums = data.get("clean_data", [])

if len(nums) == 0:
    print(json.dumps({"error":"no data"}))
    exit()

avg = sum(nums)/len(nums)
mx = max(nums)
mn = min(nums)

print(json.dumps({
    "avg": avg,
    "max": mx,
    "min": mn,
    "count": len(nums)
}))
