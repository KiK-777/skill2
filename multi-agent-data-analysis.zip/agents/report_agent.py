
import sys, json

data = json.loads(sys.argv[1])

report = f"Data count: {data.get('count')}\nAverage: {data.get('avg')}\nMax: {data.get('max')}\nMin: {data.get('min')}"

print(json.dumps({
    "report": report
}))
