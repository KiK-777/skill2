
import sys, json

data = json.loads(sys.argv[1])
numbers = data.get("numbers", [])
clean = [x for x in numbers if isinstance(x, (int,float))]

print(json.dumps({
    "clean_data": clean,
    "count": len(clean)
}))
